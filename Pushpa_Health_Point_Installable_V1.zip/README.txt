Pushpa Health Point – Installable App V1
========================================
This version includes manifest + service worker for Android PWA installation.

IMPORTANT:
- PWA installation requires the app to be opened from an HTTPS website (or localhost).
- Opening index.html directly from a downloaded ZIP/file manager will NOT normally show Install/Add to Home Screen.
- Upload all files in this folder to an HTTPS static host. Then open that HTTPS address in Chrome.
- The app includes an Install button when the browser supports installation.
